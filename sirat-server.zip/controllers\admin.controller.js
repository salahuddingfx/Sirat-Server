const orderService = require("../service/order.service");
const productService = require("../service/product.service");
const { db } = require("../config/db.config");
const { user } = require("../db/schema");
const { eq, count, desc } = require("drizzle-orm");
const { sendStatusUpdateEmail } = require("../service/mail.service");
const cache = require("../config/cache.config");

const getDashboardStats = async (req, res) => {
  try {
    const stats = await cache.getOrSet(
      cache.buildKey("dashboard", "stats"),
      async () => {
        const totalOrders = await orderService.getOrders();
        const totalProducts = await productService.getAllProducts();
        
        const [totalUsersRes] = await db.select({ value: count() })
          .from(user)
          .where(eq(user.role, "user"));
        const totalUsers = totalUsersRes.value;

        const revenue = totalOrders.reduce((acc, order) => acc + order.totalAmount, 0);
        const lowStock = totalProducts.filter((p) => p.stock < 10).length;

        return {
          revenue,
          orderCount: totalOrders.length,
          userCount: totalUsers,
          lowStockCount: lowStock,
          recentOrders: totalOrders.slice(0, 5),
          recentProducts: totalProducts.slice(0, 5),
        };
      },
      30
    );
    res.status(200).json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const getAllOrders = async (req, res) => {
  try {
    const orders = await cache.getOrSet(cache.buildKey("orders", "all"), () => orderService.getOrders(), 15);
    res.status(200).json({ success: true, data: orders });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateOrderStatus = async (req, res) => {
  try {
    const orderRecord = await orderService.updateOrderStatus(req.params.id, req.body.status);

    // Notify customer in background
    (async () => {
      try {
        await sendStatusUpdateEmail(orderRecord);
      } catch (err) {
        console.error("Status update email failed:", err);
      }
    })();

    cache.invalidateNamespace("orders");
    cache.invalidateNamespace("dashboard");
    res.status(200).json({ success: true, data: orderRecord });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getAllUsers = async (req, res) => {
  try {
    const users = await db.query.user.findMany({
      columns: {
        id: true,
        name: true,
        email: true,
        username: true,
        phone: true,
        role: true,
        avatar: true,
        createdAt: true,
      },
      orderBy: [desc(user.createdAt)],
    });
    res.status(200).json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;
    await db.update(user)
      .set({ role })
      .where(eq(user.id, req.params.id));

    const updatedUser = await db.query.user.findFirst({
      where: eq(user.id, req.params.id),
      columns: { id: true, name: true, email: true, role: true },
    });
    res.status(200).json({ success: true, data: updatedUser });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const deleteUser = async (req, res) => {
  try {
    await db.delete(user).where(eq(user.id, req.params.id));
    res.status(200).json({ success: true, message: "User deleted" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getCacheStats = async (req, res) => {
  try {
    res.status(200).json({ success: true, data: cache.stats() });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const flushCache = async (req, res) => {
  try {
    cache.flush();
    res.status(200).json({ success: true, message: "Cache flushed" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

const updatePaymentStatus = async (req, res) => {
  try {
    const { paymentStatus } = req.body;
    const orderRecord = await orderService.updatePaymentStatus(req.params.id, paymentStatus);
    cache.invalidateNamespace("orders");
    cache.invalidateNamespace("dashboard");
    res.status(200).json({ success: true, data: orderRecord });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const updateOrderDetails = async (req, res) => {
  try {
    const updates = req.body;
    const orderRecord = await orderService.updateOrderDetails(req.params.id, updates);
    cache.invalidateNamespace("orders");
    cache.invalidateNamespace("dashboard");
    res.status(200).json({ success: true, data: orderRecord });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const deleteOrder = async (req, res) => {
  try {
    const result = await orderService.deleteOrder(req.params.id);
    cache.invalidateNamespace("orders");
    cache.invalidateNamespace("dashboard");
    res.status(200).json({ success: true, message: result.message });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

const getOrderById = async (req, res) => {
  try {
    const orderRecord = await orderService.getOrderById(req.params.id);
    if (!orderRecord) return res.status(404).json({ success: false, message: "Order not found" });
    res.status(200).json({ success: true, data: orderRecord });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getDashboardStats,
  getAllOrders,
  getOrderById,
  updateOrderStatus,
  updatePaymentStatus,
  updateOrderDetails,
  deleteOrder,
  getAllUsers,
  updateUserRole,
  deleteUser,
  getCacheStats,
  flushCache,
};
